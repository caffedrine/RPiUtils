#!/usr/bin/env python

import IIC

if __name__ == "__main__":
    iviic = IIC.IIC(addr=(0x70), bus_enable =(0x01))
